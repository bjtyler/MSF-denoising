function R2 = DenoisedGoodnessOfFit(rawimage,msfmodel,nfac,seg,ipeaks)
% Copyright:  Bonnie J Tyler, 2021
% This function calculates the weight sum of squared residuals, Qres, for 
%inverse MSF denoising as explained in Tyler et al, ?Denoising of Mass 
%Spectrometry Images via inverse Maximum Signal Factors Analysis?, 
%Analytical Chemistry, 2022. 
% 
% Input:  
% 
% 1.	rawimage: The mass spectrometry image used to calculate the MSF model.
% 2.	msfmodel:  A structured variable containing the output from the 
%       function MSF.
% 3.	nfac: The number of factors to use in inverse transform.  
%       This number must be less than or equal to the number of factors used
%       in calculating the model.
% 4.    seg: The segmented image.  
% 5.	ipeak:  optional input, allows the user to calculate R2 for only
%       the specified  peaks.  If left empty, the R2 values will be 
%       calculated for all peaks used in the MSF.  Calculating for only a 
%       subset of peaks is recommended if you have limited computer memory.
% 
% Output:  Qr the weighted sum of squared residuals for the denoised image.

if nargin<5
    np = length(msfmodel.mean);
    ipeaks = 1:np;
end
npix = size(msfmodel.scores,1);
nregions = max(seg);
dnimage = msfmodel.scores(:,1:nfac)*msfmodel.fac(ipeaks,1:nfac)' + repmat(msfmodel.mean(ipeaks),npix,1);;
for ip = 1:nregions
    rawmu(ip,:) = mean(rawimage(seg==ip,ipeaks),1);
    dnmu(ip,:) = mean(dnimage(seg==ip,:),1);
end
R2 = 1 - sum((rawmu-dnmu).^2)./sum(rawmu.^2);
end

