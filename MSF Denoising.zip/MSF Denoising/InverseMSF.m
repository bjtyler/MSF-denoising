function DNimage = InverseMSF(msfmodel,nfac,peak_index)
% This function performs the inverse MSF function as explained in Tyler et al,
% ?Denoising of Mass Spectrometry Images via inverse Maximum Signal Factors 
% Analysis?, Analytical Chemistry, 2022. 
% 
% Input:  
% 
% 1.	msfmodel:  A structured variable containing output from the function MSF.
% 2.	nfac:  The number of factors to use in inverse transform.  This number
%     must be less than or equal to the number of factors used in calculating 
%     the model.
% 3.	peak_index:  optional input, allows the user to calculate the denoised 
%     image for only the peaks indicated.  If left empty, denoised images will
%     be calculated for all peaks used in the MSF.  This option is recommended
%     if you have limited computer memory.    



if nargin<3
    npeaks = length(msfmodel.mean);
    peak_index = 1:npeaks;
end
npix = size(msfmodel.scores,1);
DNimage = msfmodel.scores(:,1:nfac)*msfmodel.fac(peak_index,1:nfac)' + repmat(msfmodel.mean(peak_index),npix,1);
DNimage(~msfmodel.keep,:) = 0;
DNimage(DNimage<0) = 0;
