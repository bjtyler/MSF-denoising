function output = MSF(rawimage,nfac,nrow,ncol,keep);
% This function performs maximum signal factors, MSF, on a hyperspectral 
% image as explained in Tyler et al, ?Denoising of Mass Spectrometry Images
% via inverse Maximum Signal Factors Analysis?, Analytical Chemistry, 2022.  
% The algorithm uses the 2D Haar wavelet coeficients to estimate the image 
% noise. The algorithm also mean centers the data.
% 
% Input variables
% 1.	rawimage: Each row of the input data 'rawimage' must contain the 
%         mass spectrum for a given pixels. Each column contains the wrapped 
%         image for a given peak. The image should be wrapped such that the 
%         first 1 to nrows of the rawimage, contain the spectra from the 
%         first column of the unwrapped image.  rows (nrows+1) to 2*nrows 
%         contain the second column and so forth. 
% 2.	nfac: The number of factors to be calculated.  If it is empty, 25 
%        factors will be calculated
% 3.	nrows:  The number of rows in the unwrapped rawimage.
% 4.	ncols: The number of columns in the unwrapped rawimage. The product
%       of nrows and ncols must equal the first dimension in the wrapped 
%       rawimage. If ncols is left empty, it will be calculated using nrows
%       and the first matrix dimension of the rawimage. If both of these 
%       values are left empty, the image will be presumed to be square, 
%       and they will be set to the square root of the first matrix 
%       dimension of rawimage.
% 5.	keep:  Allows the user to restrict calculation of the MSF loadings
%       to a region of interest  'keep' is a logical vector containing ones
%       in the region of interest and zeros outside that region.  If keep 
%       is not specified, the full image will be used.
% 
% output: Is a structured variable containing the following fields
% 
% loads:	The MSF factor loadings.
% lambda:	The MSF eigenvalues	
% scores:	
% fac:	The transposed inverted MSF factor loadings.
% mean:  	The mean for each peak in the region specified by keep. 
%           If keep was not specified, this will be the mean for the full 
%           image.
% Verr:	The error covariance matrix for the ROI in the rawdata
% V:	The covariance matrix for the ROI in the rawdata.
% keep:	The region of interest used for the calulation.
% 
% Copyright:  Bonnie J Tyler, 2021

if nargin<3
    nrow = sqrt(size(rawimage,1));
    ncol = nrow;
    if round(nrow)~=nrow
        display('image is not square, you must enter image dimensions');
        return
    end
end
if nargin<2|isempty(nfac)
    nfac = 25;
end
if nargin<6|isempty(keep);
    keep = logical(ones(nrow*ncol,1));
end
nbin = 2;
hwait = waitbar(0.25,'calculating covariance matrix');
%calculate the image covariance matrix
mn = full(mean(rawimage(keep,:)));
V = (full(rawimage(keep,:)'*rawimage(keep,:)) - sum(keep(:))*(mn'*mn))/sum(keep(:));
waitbar(0.50,hwait,'calculating error covariance matrix');
%calculate the Haar Wavelet coefficients
Hmat = haarmat(nrow,ncol,nbin);
bimage = (Hmat*rawimage)/nbin.^2;
%find valid regions for Haar coefficients
keep2 = (Hmat*keep)== nbin.^2;
%calculate the signal covariance
mnb = mean(bimage(keep2,:));
Vb = full((bimage(keep2,:)'*bimage(keep2,:) - sum(keep2)*(mnb'*mnb))/sum(keep2));
%calculate the noise covariance matrix
Verr = (V - Vb)*4/3;
%remove any zero values along diagonal
diagVerr = diag(Verr);
izero = find(diagVerr==0);
for k = 1:length(izero)
    Verr(izero(k),izero(k)) = 1;
end
V = full(V)*sum(keep)/(sum(keep)-1);
Verr = full(Verr);
waitbar(.80,hwait,'calculating eigenvectors');
%calculate eigenvectors and eigenvalues
[lo,lambda] = eigs(V,Verr,nfac);
lambda = diag(lambda);
%calculate inverse loadings and scores
fac = Verr*lo;
waitbar(.90,hwait,'calculating scores');
sc = rawimage*lo - repmat(mn*lo,nrow*ncol,1);
%assign output
output.loads = lo;
output.lambda = lambda;
output.scores = sc;
output.fac = fac;
output.mean = mn;
output.Verr = Verr;
output.V = V;
output.keep = keep;
delete(hwait)
end

function S = haarmat(nrow,ncol,factor);
nz = nrow*ncol;
mrow = nrow/factor;
mcol = ncol./factor;
mz = nz./factor.^2;
jind = (1:mz)';
jcol = ceil(jind/mrow)-1;
jrow = (jind - mrow*jcol)-1;
column1 = repmat((0:factor-1)*nrow,factor,1) + repmat((1:factor)',1,factor);
column1 = column1(:);
indcolumns = repmat(column1',mz,1) + factor*repmat(jrow(:),1,factor.^2)+factor*nrow*repmat(jcol(:),1,factor.^2);
S = sparse(repmat(jind,1,factor.^2),indcolumns,1);
end