function Qr = imageQres(rawimage,msfmodel,nfac,roi);
% Copyright:  Bonnie J Tyler, 2021
% This function calculates the weight sum of squared residuals, Qres, for 
%inverse MSF denoising as explained in Tyler et al, ?Denoising of Mass 
%Spectrometry Images via inverse Maximum Signal Factors Analysis?, 
%Analytical Chemistry, 2022. 
% 
% Input:  
% 
% 1.	rawimage: The mass spectrometry image used to calculate the MSF model.
% 2.	msfmodel:  A structured variable containing the output from the 
%       function MSF.
% 3.	nfac: The number of factors to use in inverse transform.  
%       This number must be less than or equal to the number of factors used
%       in calculating the model.  
% 4.	roi:  optional input, allows the user to calculate the residual for
%       only a specified region of interest.  If left empty, Qres values 
%       will be the full image.  
%       Calculating for smaller regions of interest is recommended if you 
%       have limited computer memory.
% 
% Output:  Qr the weighted sum of squared residuals for the denoised image.

if nargin<4
    roi = logical(ones(size(msfmodel.scores,1),1));
end
npix = sum(roi);
hwait = waitbar(0.5,'calculating Qres');
dnroi = msfmodel.scores(roi,1:nfac)*msfmodel.fac(:,1:nfac)' + repmat(msfmodel.mean,npix,1);
res = rawimage(roi,:)-dnroi;
Qr = sum(res/msfmodel.Verr.*res,2);
close(hwait)
end

