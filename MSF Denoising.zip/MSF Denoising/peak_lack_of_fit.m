function F = peak_lack_of_fit(rawimage,msfmodel,nfac,ipeaks);
% Copyright:  Bonnie J Tyler, 2021
% This function calculates the peak lack of fit value, F, for inverse MSF 
%denoising as explained in Tyler et al, ?Denoising of Mass Spectrometry 
%Images via inverse Maximum Signal Factors Analysis?, Analytical Chemistry,
%2022. 
% 
% Input:  
% 
% 1.	rawimage: The mass spectrometry image used to calculate the MSF model.
% 2.	msfmodel:  A structured variable containing the output from the 
%       function MSF.
% 3.	nfac: The number of factors to use in inverse transform.  
%       This number must be less than or equal to the number of factors used in calculating the model.  
% 4.	ipeaks:  optional input, allows the user to calculate F for only
%       the specified  peaks.  If left empty, lack of fit values will be 
%       calculated for all peaks used in the MSF.  Calculating for only a 
%       subset of peaks is recommended if you have limited computer memory.
% 
% Output:  F the peak lack-of-fit statistic.

if nargin<4
    np = length(msfmodel.mean);
    peaks = 1:np;
end
npix = size(msfmodel.scores,1);
dnpeak = msfmodel.scores(:,1:nfac)*msfmodel.fac(ipeaks,1:nfac)' + repmat(msfmodel.mean(ipeaks),npix,1);
res = dnpeak - rawimage(:,ipeaks);
SSR = mean(res(msfmodel.keep,:).^2);
g = diag(msfmodel.Verr);
F = SSR./g(ipeaks)';
